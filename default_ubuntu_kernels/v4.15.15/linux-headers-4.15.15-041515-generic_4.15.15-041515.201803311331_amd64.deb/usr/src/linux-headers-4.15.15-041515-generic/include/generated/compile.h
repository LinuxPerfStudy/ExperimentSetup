/* This file is auto generated, version 201803311331 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201803311331 SMP Sat Mar 31 17:34:21 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-8ubuntu3.2)"
