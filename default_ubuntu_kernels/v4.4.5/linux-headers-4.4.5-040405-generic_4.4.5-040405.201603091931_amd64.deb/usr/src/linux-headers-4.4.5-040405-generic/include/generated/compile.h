/* This file is auto generated, version 201603091931 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201603091931 SMP Thu Mar 10 00:34:17 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 5.2.1 20151010 (Ubuntu 5.2.1-22ubuntu2) "
