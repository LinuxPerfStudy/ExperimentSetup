#define UTS_RELEASE "3.3.6-030306-generic"
