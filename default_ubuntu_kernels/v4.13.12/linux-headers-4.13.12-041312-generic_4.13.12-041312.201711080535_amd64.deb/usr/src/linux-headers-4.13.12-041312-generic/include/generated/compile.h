/* This file is auto generated, version 201711080535 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201711080535 SMP Wed Nov 8 10:40:26 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-8ubuntu3)"
