/* This file is auto generated, version 201207191609 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201207191609 SMP Thu Jul 19 20:11:13 UTC 2012"
#define LINUX_COMPILE_BY "apw"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
