/* This file is auto generated, version 201808090733 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201808090733 SMP Thu Aug 9 11:36:56 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 8.2.0 (Ubuntu 8.2.0-1ubuntu2)"
