/* This file is auto generated, version 201606100356 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201606100356 SMP Fri Jun 10 07:58:15 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 5.3.1 20160528 (Ubuntu 5.3.1-21ubuntu11) "
