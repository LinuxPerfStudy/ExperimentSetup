/* This file is auto generated, version 201510270124 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201510270124 SMP Tue Oct 27 01:25:49 UTC 2015"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 5.2.1 20151010 (Ubuntu 5.2.1-22ubuntu2) "
