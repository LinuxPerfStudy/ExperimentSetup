/* This file is auto generated, version 201702181031 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201702181031 SMP Sat Feb 18 15:33:41 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 6.2.0 20161005 (Ubuntu 6.2.0-5ubuntu12) "
