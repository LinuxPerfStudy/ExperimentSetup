/* This file is auto generated, version 201607111332 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201607111332 SMP Mon Jul 11 17:34:50 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 5.4.0 20160609 (Ubuntu 5.4.0-6ubuntu1) "
