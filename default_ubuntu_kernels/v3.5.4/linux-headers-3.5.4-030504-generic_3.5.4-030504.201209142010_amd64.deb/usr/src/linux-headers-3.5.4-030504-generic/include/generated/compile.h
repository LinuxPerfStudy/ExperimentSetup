/* This file is auto generated, version 201209142010 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201209142010 SMP Sat Sep 15 00:11:50 UTC 2012"
#define LINUX_COMPILE_BY "apw"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
