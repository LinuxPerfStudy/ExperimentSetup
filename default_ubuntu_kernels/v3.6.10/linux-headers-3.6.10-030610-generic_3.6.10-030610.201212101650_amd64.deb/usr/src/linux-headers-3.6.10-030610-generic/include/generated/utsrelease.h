#define UTS_RELEASE "3.6.10-030610-generic"
