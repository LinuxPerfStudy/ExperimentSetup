/* This file is auto generated, version 201401151952 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201401151952 SMP Thu Jan 16 00:53:39 UTC 2014"
#define LINUX_COMPILE_BY "apw"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
