/* This file is auto generated, version 201902270533 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201902270533 SMP Wed Feb 27 10:35:20 UTC 2019"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 8.2.0 (Ubuntu 8.2.0-21ubuntu1)"
