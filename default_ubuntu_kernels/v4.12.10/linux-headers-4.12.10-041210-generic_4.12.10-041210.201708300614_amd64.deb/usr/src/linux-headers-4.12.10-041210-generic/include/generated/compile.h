/* This file is auto generated, version 201708300614 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201708300614 SMP Wed Aug 30 10:16:40 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 7.1.0 (Ubuntu 7.1.0-13ubuntu1) "
