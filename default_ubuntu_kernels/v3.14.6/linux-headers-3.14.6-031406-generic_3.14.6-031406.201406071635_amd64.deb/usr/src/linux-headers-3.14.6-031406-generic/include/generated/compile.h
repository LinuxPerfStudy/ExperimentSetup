/* This file is auto generated, version 201406071635 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201406071635 SMP Sat Jun 7 20:36:01 UTC 2014"
#define LINUX_COMPILE_BY "apw"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
