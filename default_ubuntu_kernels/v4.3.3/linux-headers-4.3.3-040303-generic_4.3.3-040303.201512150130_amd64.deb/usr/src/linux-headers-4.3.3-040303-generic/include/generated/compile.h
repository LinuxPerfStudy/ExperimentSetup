/* This file is auto generated, version 201512150130 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201512150130 SMP Tue Dec 15 06:32:30 UTC 2015"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 5.2.1 20151010 (Ubuntu 5.2.1-22ubuntu2) "
