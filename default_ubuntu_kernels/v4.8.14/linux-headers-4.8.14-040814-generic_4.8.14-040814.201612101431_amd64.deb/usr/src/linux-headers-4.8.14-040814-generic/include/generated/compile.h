/* This file is auto generated, version 201612101431 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201612101431 SMP Sat Dec 10 19:33:51 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 6.2.0 20161005 (Ubuntu 6.2.0-5ubuntu12) "
