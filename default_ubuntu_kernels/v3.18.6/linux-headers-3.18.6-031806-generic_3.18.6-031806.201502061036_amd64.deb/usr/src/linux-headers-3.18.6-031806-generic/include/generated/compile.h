/* This file is auto generated, version 201502061036 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201502061036 SMP Fri Feb 6 15:38:09 UTC 2015"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
